<?php

namespace Elchinomandaron\RulesV1.0.0ELC;

use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;

class Main extends PluginBase implements Listener {   

    public function onEneable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "help") {
            if ($sender instanceof Player) {
                switch ($args[0] ?? "") {
                    default:
                        $sender->sendMessage(TextFormat::RED . "Usage: /" . $label . " rules");
                        break;
                }
            } else {
                $sender->sendMessage(TextFormat::BLACK . "=================================================");
                        $sender->sendMessage(TextFormat::RED . "§lReglas");
                        $sender->sendMessage(TextFormat::YELLOW . "/".$label." Not hacks or ClientHacks:");
                        $sender->sendMessage(TextFormat::RED . "/".$label." Judgement: 30 days");
                        $sender->sendMessage(TextFormat::YELLOW . "/".$label." Not truce");
                        $sender->sendMessage(TextFormat::RED . "/".$label." Judgement: 5 days");
											  $sender->sendMessage(TextFormat::YELLOW . "/".$label." not Content +18");
											  $sender->sendMessage(TextFormat::RED . "/".$label." Judgement: 1 day");
                        $sender->sendMessage(TextFormat::YELLOW . "/".$label." Not spam\flood");
												$sender->sendMessage(TextFormat::RED . "/".$label." Judgement: 1 day mute");
                $sender->sendMessage(TextFormat::BLACK . "=================================================");
  }
            return true;
        }
        return false;
    }

    public function onDisable(): void {
        // Código de limpieza cuando se desactiva el plugin
    }
}

































												






























